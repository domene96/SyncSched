import UIKit
import EventKit


class ViewControllerInfo: UIViewController {
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        return UIInterfaceOrientationMask.portrait
    }
    override var shouldAutorotate: Bool {
        return false
    }
    @IBOutlet weak var Name: UILabel!
    @IBOutlet weak var loc: UILabel!
    @IBOutlet weak var date: UILabel!
    @IBOutlet weak var organaizer: UILabel!
    
    var unEvento : Event?
    var startDate : Date?
    var endDate : Date?
    var dateFinal : Date?

    @IBAction func handleQuitarTeclado(_ sender: UITapGestureRecognizer) {
        view.endEditing(true)
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //print(unEvento)
        Name.text = unEvento?.eventName
        loc.text = unEvento?.eventFinalLocation
        date.text = unEvento?.eventFinalDate
        organaizer.text = unEvento?.eventOrganizer
        //startDate = Date(unEvento?.eventFinalDate)
        // Do any additional setup after loading the view.
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "MM-dd-yyyy HH:mm"
        dateFormatter.timeZone = TimeZone(abbreviation: "CST+0:00")
         dateFinal = dateFormatter.date(from: (unEvento?.eventFinalDate)!)
        print(dateFinal)
    }
    
    @IBAction func addCalendar(_ sender: UIButton) {
        
        let eventStore: EKEventStore = EKEventStore()
        eventStore.requestAccess(to: .event){(granted,error) in
            
            if(granted) && (error == nil)
            {
                //print ("GRANTED \(granted)")
                //print("ERROR \(error)")
                
                let event:EKEvent = EKEvent(eventStore: eventStore)
                event.title = self.unEvento?.eventName
                event.startDate = self.dateFinal
                event.endDate = self.dateFinal
                event.notes = "SyncSched Event"
                event.location = self.unEvento?.eventFinalLocation

                event.calendar = eventStore.defaultCalendarForNewEvents
                do {
                    try eventStore.save(event, span: .thisEvent)
                }catch let error as NSError{
                    print("error: \(error)")
                }
                print("Save Event")
            }else{
                print("error: \(String(describing: error))")
            }
            
        }
        
    }
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
