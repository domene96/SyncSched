import UIKit
import EventKit
import Firebase
import FirebaseDatabase

class CreateEventViewController: UIViewController, UITextFieldDelegate {
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        return UIInterfaceOrientationMask.portrait
    }
    override var shouldAutorotate: Bool {
        return false
    }
    let delegate = UIApplication.shared.delegate as! AppDelegate

    var unArray: [String] = []
    var initialDate : Int?
    var initialYear : Int?
    var initialMonth : Int?


    @IBOutlet weak var tfEventName: UITextField!
    @IBOutlet weak var tfLocation: UITextField!
    @IBOutlet weak var txtDatePicker: UITextField!
    let datePicker = UIDatePicker()
    
    var eventName: String!
    var location : String!
    var name : String!
    var activefield : UITextField!
    
    @IBOutlet weak var scrollview: UIScrollView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        showDatePicker()
        name = delegate.name
        print(name)
        //print(unArray)
        
        //////////////////
        let tap = UITapGestureRecognizer(target: self, action: #selector(quitaTeclado))
        self.view.addGestureRecognizer(tap)
        /////////////
        tfEventName.delegate = self
        tfLocation.delegate = self
        txtDatePicker.delegate = self
        self.registrarseParaNotificacionesDeTeclado()
        
    }
    
    
    
    func showDatePicker(){
        //Formate Date
        datePicker.datePickerMode = .date
        
        //ToolBar
        let toolbar = UIToolbar();
        toolbar.sizeToFit()
        let doneButton = UIBarButtonItem(title: "Done", style: .plain, target: self, action: #selector(donedatePicker));
        let spaceButton = UIBarButtonItem(barButtonSystemItem: UIBarButtonItem.SystemItem.flexibleSpace, target: nil, action: nil)
        let cancelButton = UIBarButtonItem(title: "Cancel", style: .plain, target: self, action: #selector(cancelDatePicker));
        
        toolbar.setItems([doneButton,spaceButton,cancelButton], animated: false)
        
        txtDatePicker.inputAccessoryView = toolbar
        txtDatePicker.inputView = datePicker
        
    }
    
    @objc func donedatePicker(){
        
        let formatter = DateFormatter()
        formatter.dateFormat = "dd/MM/yyyy"
        let temp = formatter.string(from: datePicker.date)
        txtDatePicker.text = temp
        formatter.dateFormat = "dd"
        initialDate = Int(formatter.string(from: datePicker.date))
        formatter.dateFormat = "MM"
        initialMonth = Int(formatter.string(from: datePicker.date))
        formatter.dateFormat = "yyyy"
        initialYear = Int(formatter.string(from: datePicker.date))
        
        self.view.endEditing(true)
    }
    
    @objc func cancelDatePicker(){
        self.view.endEditing(true)
    }
    
    

    
    @IBAction func writeDatabase(_ sender: UIButton) {

        let members = ["Pepe Domene","Valentin Huerta"]
        var length : Int = 0
        let lengthArrayMembers = unArray.count
        var i = 0
        var lengths : [Int] = []
        if self.tfEventName.text! == "" && self.tfLocation.text == "" && self.txtDatePicker.text  == ""{
            let alerta = UIAlertController (title: "ERROR", message: "Los campos deben tener datos", preferredStyle: .alert)
            alerta.addAction(UIAlertAction(title: "OK", style: .cancel, handler: nil))
            self.present(alerta, animated: true, completion: nil)
        }else{
            
        let rootRef = Database.database().reference().child(unArray[i])
        rootRef.observe(.value, with: { snapshot in
            while i != lengthArrayMembers {
                
                let value = snapshot.value as? NSDictionary
                
                let todosEventos = value?["events"] as? NSArray
                length = (todosEventos?.count as? Int)!
                lengths.append(Int(length))
                
                i = i+1
            }
            self.write(lengths: lengths)
            
        })
        navigationController!.popToViewController(navigationController!.viewControllers[0] as UIViewController, animated: false)
    }
    }
    
    func write (lengths : [Int]){
    
        var j = 0
        let members = ["Pepe Domene","Valentin Huerta"]
        let lengthArrayMembers = unArray.count

        while j != lengthArrayMembers {
            let rootRef = Database.database().reference().child(unArray[j])
            let post = ["eventName": tfEventName.text,
                        "eventFinalDate": "",
                        "eventFinalLocation": "",
                        "eventOrganizer": name,
                        "eventState": "amarillo",
                        "eventLocations": tfLocation.text,
                        "eventSchedules": [""],
                        "eventMembers": unArray,
                        "initialDate": initialDate,
                        "initialYear": initialYear,
                        "initialMonth": initialMonth] as [String : Any]
            rootRef.child("events").child(String(lengths[j])).setValue(post)
            j = j+1
        }
    }
    
    /*
    @IBAction func handleQuitarTeclado(_ sender: UITapGestureRecognizer) {
        view.endEditing(true)
    }
    
    */
    
    @IBAction func quitaTeclado(_ sender: UITapGestureRecognizer) {
        view.endEditing(true)
    }
    
    func registrarseParaNotificacionesDeTeclado() {
        NotificationCenter.default.addObserver(self, selector:#selector(keyboardWasShown(aNotification:)),
                                               name:UIResponder.keyboardWillShowNotification, object:nil)
        NotificationCenter.default.addObserver(self, selector:#selector(keyboardWillBeHidden(aNotification:)),
                                               name:UIResponder.keyboardWillHideNotification, object:nil)
    }
    
    /*
     func textFieldShouldReturn(_ textField: UITextField) -> Bool {
     self.view.endEditing(true)
     return false
     }
     */
    
    @IBAction func keyboardWasShown(aNotification : NSNotification) {
        
        let kbSize = (aNotification.userInfo![UIResponder.keyboardFrameEndUserInfoKey] as! NSValue).cgRectValue.size

        
        let contentInset = UIEdgeInsets(top: 0.0, left: 0.0, bottom: kbSize.height, right: 0.0)
        scrollview.contentInset = contentInset
        scrollview.scrollIndicatorInsets = contentInset
        
        // If active text field is hidden by keyboard, scroll it so it's visible
        // Your app might not need or want this behavior.
//        var aRect: CGRect = self.scrollview.frame
//        aRect.size.height -= kbSize.height
//        print(activefield)
//        if !aRect.contains(self.activefield.frame.origin) {
//            scrollview.scrollRectToVisible(activefield.frame, animated: true)
//        }
//        activefield = nil

    }
    
    // Called when the UIKeyboardWillHideNotification is sent
    @IBAction func keyboardWillBeHidden(aNotification : NSNotification) {
        let contentInsets = UIEdgeInsets.zero
        scrollview.contentInset = contentInsets
        scrollview.scrollIndicatorInsets = contentInsets
    }
    
    // OJO poner atención a este comentario
    // Each text field in the interface sets the view controller as its delegate.
    // Therefore, when a text field becomes active, it calls these methods.
    func textFieldDidBeginEditing (_ textField : UITextField )
    {
        activefield = textField
        //lastOffset = self.scrollview.contentOffset
        //return true
    }
    
    func textFieldDidEndEditing (_ textField : UITextField )
    {
        activefield = nil
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
       // activefield?.resignFirstResponder()
        activefield = nil
        self.view.endEditing(true)
        return true
    }
    
}


