
import UIKit

protocol protocoloAgregarMiembro{
    func agregaMiembro(miembro : String) -> Void
}

class AgregarMiembroViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var agregarButton: UIButton!
    @IBOutlet weak var tfEmail: UITextField!
    
    @IBOutlet weak var prueba: UITextField!
    
    //var activeField : UITextField!

    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        return UIInterfaceOrientationMask.portrait
    }
    override var shouldAutorotate: Bool {
        return false
    }

    
    var delegado : protocoloAgregarMiembro!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //////////////////
        let tap = UITapGestureRecognizer(target: self, action: #selector(quitaTeclado))
        self.view.addGestureRecognizer(tap)
        /////////////
        tfEmail.delegate = self
        //self.registrarseParaNotificacionesDeTeclado()
        
    }

    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func guardarMiembro(_ sender: UIButton) {
        let nombre =  String(tfEmail.text!)
        if tfEmail.text! == "" {
            let alerta = UIAlertController (title: "ERROR", message: "Los campos deben tener datos", preferredStyle: .alert)
            alerta.addAction(UIAlertAction(title: "OK", style: .cancel, handler: nil))
            present(alerta, animated: true, completion: nil)
        }else{
            delegado.agregaMiembro(miembro: nombre)
            navigationController?.popViewController(animated: true)
        }
    }
    

    
    
    @IBAction func quitaTeclado(_ sender: UITapGestureRecognizer) {
        view.endEditing(true)
    }
//
//    func registrarseParaNotificacionesDeTeclado() {
//        NotificationCenter.default.addObserver(self, selector:#selector(keyboardWasShown(aNotification:)),
//                                               name:UIResponder.keyboardWillShowNotification, object:nil)
//        NotificationCenter.default.addObserver(self, selector:#selector(keyboardWillBeHidden(aNotification:)),
//                                               name:UIResponder.keyboardWillHideNotification, object:nil)
//    }
//
    /*
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.view.endEditing(true)
        return false
    }
    */
    
//    @IBAction func keyboardWasShown(aNotification : NSNotification) {
//
//        let Size = (aNotification.userInfo![UIResponder.keyboardFrameEndUserInfoKey] as AnyObject).cgRectValue.size
//
//        let contentInset = UIEdgeInsets(top: 0.0, left: 0.0, bottom: Size.height, right: 0.0)
//        scrollView.contentInset = contentInset
//        scrollView.scrollIndicatorInsets = contentInset
//
//        // If active text field is hidden by keyboard, scroll it so it's visible
//        // Your app might not need or want this behavior.
//        var rect: CGRect = scrollView.frame
//        rect.size.height -= Size.height
//        print(activeField)
//        if rect.contains(activeField.frame.origin) {
//            scrollView.scrollRectToVisible(activeField.frame, animated: true)
//        }
//    }
//
//    // Called when the UIKeyboardWillHideNotification is sent
//    @IBAction func keyboardWillBeHidden(aNotification : NSNotification) {
//        let contentInsets = UIEdgeInsets.zero
//        scrollView.contentInset = contentInsets
//        scrollView.scrollIndicatorInsets = contentInsets
//    }
//
//    // OJO poner atención a este comentario
//    // Each text field in the interface sets the view controller as its delegate.
//    // Therefore, when a text field becomes active, it calls these methods.
//    func textFieldDidBeginEditing (_ textField : UITextField )
//    {
//        activeField = textField
//    }
//
//    func textFieldDidEndEditing (_ textField : UITextField )
//    {
//        activeField = nil
//    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.view.endEditing(true)
        return false
    }

}
