import Foundation
import Firebase
import FirebaseDatabase


struct Event {
    
    //let ref: DatabaseReference?
    let eventFinalDate : String
    let eventFinalLocation : String
    let eventLocations : String
    let eventMembers : NSArray
    let eventName : String
    let eventOrganizer : String
    let eventSchedules : NSArray
    let eventState : String
    let initialDate : Int
    let initialYear : Int
    let initialMonth : Int
    
    
    init(eventFinalDate: String, eventFinalLocation: String ,eventLocations: String,eventMembers: NSArray,eventName: String,eventOrganizer: String,eventSchedules: NSArray,eventState: String , initialDate: Int, initialYear : Int, initialMonth: Int) {
        self.eventFinalDate = eventFinalDate
        self.eventFinalLocation = eventFinalLocation
        self.eventLocations = eventLocations
        self.eventMembers = eventMembers
        self.eventName = eventName
        self.eventOrganizer = eventOrganizer
        self.eventSchedules = eventSchedules
        self.eventState = eventState
        self.initialDate = initialDate
        self.initialYear = initialYear
        self.initialMonth = initialMonth
    }
}


