import UIKit
import Firebase
import FirebaseDatabase


class SetEventViewController: UIViewController , UITextFieldDelegate{
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        return UIInterfaceOrientationMask.portrait
    }
    override var shouldAutorotate: Bool {
        return false
    }
    

    /*
    
    @IBAction func tap(_ sender: UITapGestureRecognizer) {
        view.endEditing(true)
    }
    
    */
    
    let delegate =  UIApplication.shared.delegate as! AppDelegate
    var name : String!
    var unEvento : Event?
    var indexRow : Int?
    var FinalDate : String?
    var eventMembers: NSArray?
    var countMembers: Int?
    var diaSemana: Int?
    var hora: String? = " "
    var fecha: String? = ""
    var activeField : UITextField!
    
    @IBOutlet weak var scrollView: UIScrollView!
    
//    var ArregloTotalFinal : NSArray?
    var ArregloTotalFinal = [Int](repeating: 0, count: 112)

    @IBOutlet weak var tfLocation: UITextField!
    @IBOutlet weak var eventName: UILabel!
    @IBOutlet weak var Date1Button: UIButton!

    override func viewDidLoad() {
        super.viewDidLoad()
        eventName.text = unEvento?.eventName
        tfLocation.text = unEvento?.eventFinalLocation
        eventMembers = unEvento?.eventMembers
        countMembers = eventMembers?.count
        
        //////////////////
        let tap = UITapGestureRecognizer(target: self, action: #selector(quitaTeclado))
        self.view.addGestureRecognizer(tap)
        /////////////
        
        self.registrarseParaNotificacionesDeTeclado()
        
        arrtot()
    }
    
func arrtot(){
        var j = 0
        let index = String(indexRow!)
        while j != countMembers {
            let rootRef = Database.database().reference().child(eventMembers![j] as! String).child("events").child(index).child("eventSchedules")
            rootRef.observe(.value, with: { snapshot in
            let value = snapshot.value as? NSArray
               for i in 0...111{
                var temp = value![i] as! Int
                var suma : Int? = self.ArregloTotalFinal[i] + temp
                self.ArregloTotalFinal[i] = suma!
                }
                self.pos(ArregloTotalFinal:self.ArregloTotalFinal)
            })
        j = j+1
    }
}
    func pos(ArregloTotalFinal : [Int]){
        
        var numMayor : Int = 0
        var posMayor : Int = 0
        
        for i in 0...ArregloTotalFinal.count-1 {
            if(ArregloTotalFinal[i] > numMayor){
            numMayor = ArregloTotalFinal[i]
            posMayor = i
            }
        }
        
        traduccionHorasFinal(posMay : posMayor)
        
        
    }
    
    
    func traduccionHorasFinal(posMay: Int){
    
        
        
        //Lunes
        if posMay >= 0 && posMay <= 15{
            diaSemana = 0 //lunes
            hora = String(posMay+7)+":00"
        }
        //Martes
        if posMay >= 16 && posMay <= 31{
            diaSemana = 1 //martes
            hora = String(posMay-9)+":00"
        }
        //Miercoles
        if posMay >=  32 && posMay <= 47{
            diaSemana = 2 // miercoles
            hora = String(posMay-25)+":00"
        }
        //Jueves
        if posMay >= 48 && posMay <= 63{
            diaSemana = 3 // jueves
            hora = String(posMay-41)+":00"
        }
        //Viernes
        if posMay >= 64 && posMay <= 79{
            diaSemana = 4 //viernes
            hora = String(posMay-57)+":00"
        }
        //Sabado
        if posMay >=  80 && posMay <= 95{
            diaSemana = 5 //sabadp
            hora = String(posMay-73)+":00"
        }
        //Domingo
        if posMay >=  96 && posMay <= 111{
            diaSemana = 6 //domingo
            hora = String(posMay-89)+":00"
        }
        //print(diaSemana)
        print(hora)
        let initi : Int = (unEvento?.initialDate)!
        let temp : Int = initi + diaSemana!
        let temp2 : Int = (unEvento?.initialMonth)!
        let temp3 : Int = (unEvento?.initialYear)!
        
        
        fecha = String(temp2) + "-" + String(temp)
        fecha = fecha! + "-" + String(temp3) + " " + hora!
        print(fecha)
        Date1Button.setTitle(fecha, for: [])
    }
    
    
    @IBAction func Date1(_ sender: UIButton) {
        FinalDate = Date1Button.titleLabel!.text
    }
    
    @IBAction func FinalSet(_ sender: UIButton) {
    var j = 0
        if tfLocation.text! == "" {
            let alerta = UIAlertController (title: "ERROR", message: "Los campos deben tener datos", preferredStyle: .alert)
            alerta.addAction(UIAlertAction(title: "OK", style: .cancel, handler: nil))
            present(alerta, animated: true, completion: nil)
        }else{
       while j != countMembers {
        
            let rootRef = Database.database().reference().child(eventMembers![j] as! String)
                    let post = ["eventFinalDate": FinalDate,
                                    "eventFinalLocation": tfLocation.text,
                                    "eventState": "verde" ] as [String : Any]
                    let index = String(indexRow!)
                    rootRef.child("events").child(index).updateChildValues(post)
                    j = j+1
        
         }
    }
         navigationController!.popToViewController(navigationController!.viewControllers[0] as UIViewController, animated: false)

    }
    
    
    @IBAction func quitaTeclado(_ sender: UITapGestureRecognizer) {
        view.endEditing(true)
    }
    
    func registrarseParaNotificacionesDeTeclado() {
        NotificationCenter.default.addObserver(self, selector:#selector(keyboardWasShown(aNotification:)),
                                               name:UIResponder.keyboardWillShowNotification, object:nil)
        NotificationCenter.default.addObserver(self, selector:#selector(keyboardWillBeHidden(aNotification:)),
                                               name:UIResponder.keyboardWillHideNotification, object:nil)
    }
    

    @IBAction func keyboardWasShown(aNotification : NSNotification) {
        
        let kbSize = (aNotification.userInfo![UIResponder.keyboardFrameEndUserInfoKey] as AnyObject).cgRectValue.size
        
        let contentInset = UIEdgeInsets(top: 0.0, left: 0.0, bottom: kbSize.height, right: 0.0)
        scrollView.contentInset = contentInset
        scrollView.scrollIndicatorInsets = contentInset
        
        // If active text field is hidden by keyboard, scroll it so it's visible
        // Your app might not need or want this behavior.
        var aRect: CGRect = scrollView.frame
        aRect.size.height -= kbSize.height
        print(activeField)
        if aRect.contains(activeField.frame.origin) {
            scrollView.scrollRectToVisible(activeField.frame, animated: true)
        }
    }
    
    // Called when the UIKeyboardWillHideNotification is sent
    @IBAction func keyboardWillBeHidden(aNotification : NSNotification) {
        let contentInsets = UIEdgeInsets.zero
        scrollView.contentInset = contentInsets
        scrollView.scrollIndicatorInsets = contentInsets
    }
    
    // OJO poner atención a este comentario
    // Each text field in the interface sets the view controller as its delegate.
    // Therefore, when a text field becomes active, it calls these methods.
    func textFieldDidBeginEditing (_ textField : UITextField )
    {
        activeField = textField
    }
    
    func textFieldDidEndEditing (_ textField : UITextField )
    {
        activeField = nil
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.view.endEditing(true)
        return false
    }
}
