import UIKit
import Firebase
import FirebaseDatabase


class ViewControllerTabla: UIViewController {
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        return UIInterfaceOrientationMask.portrait
    }
    override var shouldAutorotate: Bool {
        return false
    }
    let delegate = UIApplication.shared.delegate as! AppDelegate
    var name : String!
    var unEvento : Event?
    var indexRow : Int?


        // Variables Globales
        var screenWidth: Int!
        var screenHeight: Int!
        
        // Variables de calculo
        var columnWidth: Int!
        var columnHeight: Int!
        var columnMargin: Int! // 4 sides
        var rowWidth: Int!
        var rowHeight: Int!
        var rowMargin: Int! // 4 sides
        
        // Variables para creacion de labels
        var listaLabel = [UILabel]()
        
        // Variables para touch
        var labelEmpieza,labelTermina : Int!
        var columnEmpieza,columnTermina : Int!
    
   
    //arreglos para las horas de cada dia
    var arrLun = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
    var arrMar = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
    var arrMier = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
    var arrJue = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
    var arrVie = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
    var arrSab = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
    var arrDom = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
    var arrTot = [Int]()
    var arrChoices = [Int]()
        
        override func viewDidLoad() {
            super.viewDidLoad()
            name = delegate.name
            //print(name)
            //print(indexRow)
            //print(unEvento)
            
            screenWidth = Int(self.view.frame.size.width)
            screenHeight = Int(self.view.frame.size.height)
            
            // Variables a calcular
           // print(screenWidth);
            //print(screenHeight);
            
            // Variables calculadas
            // Cambiar variables calculadas
            var x = 10
            var y = 100
            rowWidth = 50
            rowHeight = 60
            
            // Creacion de labels de dias de semana
            for i in 1...7 {
                // Create row of headers
                let label = UILabel(frame: CGRect(x: x, y: y, width: rowWidth, height: rowHeight))
                listaLabel.append(label)
                
                // Choose date
                var date: String!
                
                switch i {
                case 1:
                    date = "Mon"
                case 2:
                    date = "Tue"
                case 3:
                    date = "Wed"
                case 4:
                    date = "Thu"
                case 5:
                    date = "Fri"
                case 6:
                    date = "Sat"
                case 7:
                    date = "Sun"
                default:
                    date = "n.a."
                }
                
                // Assign date to label
                label.text = String(date)
                
                // Show (?)
                view.addSubview(label)
                
                x = x + (screenWidth)/7
            }
            
            // Cambiar variables calculadas
            x = 5
            y = 150
            rowWidth = 50
            rowHeight = 20
            
            // Creacion de labels de horas
            for i in 7...22 {
                // Create row of labels
                let label1 = UILabel(frame: CGRect(x: x, y: y, width: rowWidth, height: rowHeight))
                let label2 = UILabel(frame: CGRect(x: x + (screenWidth)/7, y: y, width: rowWidth, height: rowHeight))
                let label3 = UILabel(frame: CGRect(x: x + (screenWidth)/7*2, y: y, width: rowWidth, height: rowHeight))
                let label4 = UILabel(frame: CGRect(x: x + (screenWidth)/7*3, y: y, width: rowWidth, height: rowHeight))
                let label5 = UILabel(frame: CGRect(x: x + (screenWidth)/7*4, y: y, width: rowWidth, height: rowHeight))
                let label6 = UILabel(frame: CGRect(x: x + (screenWidth)/7*5, y: y, width: rowWidth, height: rowHeight))
                let label7 = UILabel(frame: CGRect(x: x + (screenWidth)/7*6, y: y, width: rowWidth, height: rowHeight))
                
                // Customize labels
                custiomizeLabel(labelName: label1)
                custiomizeLabel(labelName: label2)
                custiomizeLabel(labelName: label3)
                custiomizeLabel(labelName: label4)
                custiomizeLabel(labelName: label5)
                custiomizeLabel(labelName: label6)
                custiomizeLabel(labelName: label7)
                
                // Append labels to array
                listaLabel.append(label1)
                listaLabel.append(label2)
                listaLabel.append(label3)
                listaLabel.append(label4)
                listaLabel.append(label5)
                listaLabel.append(label6)
                listaLabel.append(label7)
                
                // Add current hour to label
                label1.text = String(i)+":00"
                label2.text = String(i)+":00"
                label3.text = String(i)+":00"
                label4.text = String(i)+":00"
                label5.text = String(i)+":00"
                label6.text = String(i)+":00"
                label7.text = String(i)+":00"
                
                // Show (?)
                view.addSubview(label1)
                view.addSubview(label2)
                view.addSubview(label3)
                view.addSubview(label4)
                view.addSubview(label5)
                view.addSubview(label6)
                view.addSubview(label7)
                
                y = y + 30
            }
        }
    
    
    @IBAction func botonHora(_ sender: Any) {
        
        
        for i in 7...118 {
            if (listaLabel[i].backgroundColor == UIColor.green) {
            arrChoices.append(1)
                
            } else {
                arrChoices.append(0)             }
        }
        
        horasEnDias()
       //print(arrChoices)
        p()
    }
    func horasEnDias(){
        
        for i in 0...15{
            //Lunes
            if arrChoices[i * 7] != 0{
                arrLun[i] = 1
            }
            //Martes
            if arrChoices[i * 7 + 1] != 0{
                arrMar[i] = 1
            }
            //Miercoles
            if arrChoices[i * 7 + 2] != 0{
                arrMier[i] = 1
            }
            //Jueves
            if arrChoices[i * 7 + 3] != 0{
                arrJue[i] = 1
            }
            //Viernes
            if arrChoices[i * 7 + 4] != 0{
                arrVie[i] = 1
            }
            //Sabado
            if arrChoices[i * 7 + 5] != 0{
                arrSab[i] = 1
            }
            //Domingo
            if arrChoices[i * 7 + 6] != 0{
                arrDom[i] = 1
            }
        }
        
        //print(arrLun, arrMar, arrMier, arrJue, arrVie, arrSab, arrDom)
        
        //agrega horarios de Lunes
        for j in 0...15{
            arrTot.append(arrLun[j])
        }
        //agrega horarios de Martes
        for j in 0...15{
            arrTot.append(arrMar[j])
        }
        //agrega horarios de Miercoles
        for j in 0...15{
            arrTot.append(arrMier[j])
        }
        //agrega horarios de Jueves
        for j in 0...15{
            arrTot.append(arrJue[j])
        }
        //agrega horarios de Viernes
        for j in 0...15{
            arrTot.append(arrVie[j])
        }
        //agrega horarios de Sabado
        for j in 0...15{
            arrTot.append(arrSab[j])
        }
        //agrega horarios de domingo
        for j in 0...15{
            arrTot.append(arrDom[j])
        }
        
        //print(arrTot)
    }
    
        func custiomizeLabel(labelName: UILabel){
            let negro = (UIColor(red: 0, green: 0, blue: 0, alpha: 1.0))
            labelName.layer.cornerRadius = 1
            labelName.layer.borderWidth = 1.2
            labelName.layer.borderColor = negro.cgColor
        }
        
        override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
            let touch = touches.first!
            let location = touch.location(in: view)
            //print(location)
            let cordBegX = Int(location.x)
            let cordBegY = Int(location.y)
            getLabelBegan(coordBegx: cordBegX, coordBegy: cordBegY)
        }
        
        override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
            let touch = touches.first!
            let location = touch.location(in: view)
            //print(location)
            let cordEndX = Int(location.x)
            let cordEndy = Int(location.y)
            getLabelEnded(coordEndX: cordEndX, coordEndY: cordEndy)
            fillLabels()
        }
        
        func getLabelBegan(coordBegx: Int, coordBegy: Int) {
            // 5 a 5+(ScreenWidth/7) => Mon
            // 5+(ScreenWidth/7) a 5+(ScreenWidth/7*2) => Tue
            // 5+(ScreenWidth/7*2) a 5+(ScreenWidth/7*3) => Wed
            // 5+(ScreenWidth/7*3) a 5+(ScreenWidth/7*4) => Thu
            // 5+(ScreenWidth/7*4) a 5+(ScreenWidth/7*5) => Fri
            // 5+(ScreenWidth/7*5) a 5+(ScreenWidth/7*6) => Sat
            // 5+(ScreenWidth/7*6) a 5+(ScreenWidth/7*7) => Sun
            
            // 70 a 90 => 7:00
            // 100 a 120 => 8:00
            // 130 - 150 => 9:00
            // 160 - 180 => 10:00
            // 190 - 210 => 11:00
            // 220 - 240 => 12:00
            // 250 - 270 => 13:00
            // 280 - 300 => 14:00
            // 310 - 330 => 15:00
            // 340 - 360 => 16:00
            // 370 - 390 => 17:00
            // 400 - 420 => 18:00
            // 430 - 450 => 19:00
            // 460 - 480 => 20:00
            // 490 - 510 => 21:00
            // 520 - 540 => 22:00
            
            let y = 150
            
            // Lunes
            if (coordBegx >= 5 && coordBegx <= 5+(screenWidth/7)) {
                columnEmpieza = 1
                if (coordBegy >= y && coordBegy <= y+20) {labelEmpieza = 7}
                if (coordBegy >= y+(30*1) && coordBegy <= y+20+(30*1)) {labelEmpieza = 8}
                if (coordBegy >= y+(30*2) && coordBegy <= y+20+(30*2)) {labelEmpieza = 9}
                if (coordBegy >= y+(30*3) && coordBegy <= y+20+(30*3)) {labelEmpieza = 10}
                if (coordBegy >= y+(30*4) && coordBegy <= y+20+(30*4)) {labelEmpieza = 11}
                if (coordBegy >= y+(30*5) && coordBegy <= y+20+(30*5)) {labelEmpieza = 12}
                if (coordBegy >= y+(30*6) && coordBegy <= y+20+(30*6)) {labelEmpieza = 13}
                if (coordBegy >= y+(30*7) && coordBegy <= y+20+(30*7)) {labelEmpieza = 14}
                if (coordBegy >= y+(30*8) && coordBegy <= y+20+(30*8)) {labelEmpieza = 15}
                if (coordBegy >= y+(30*9) && coordBegy <= y+20+(30*9)) {labelEmpieza = 16}
                if (coordBegy >= y+(30*10) && coordBegy <= y+20+(30*10)) {labelEmpieza = 17}
                if (coordBegy >= y+(30*11) && coordBegy <= y+20+(30*11)) {labelEmpieza = 18}
                if (coordBegy >= y+(30*12) && coordBegy <= y+20+(30*12)) {labelEmpieza = 19}
                if (coordBegy >= y+(30*13) && coordBegy <= y+20+(30*13)) {labelEmpieza = 20}
                if (coordBegy >= y+(30*14) && coordBegy <= y+20+(30*14)) {labelEmpieza = 21}
                if (coordBegy >= y+(30*15) && coordBegy <= y+20+(30*15)) {labelEmpieza = 22}
            }
                // Martes
            else if (coordBegx >= 5+(screenWidth/7) && coordBegx <= 5+(screenWidth/7)*2) {
                columnEmpieza = 2
                if (coordBegy >= y && coordBegy <= y+20) {labelEmpieza = 7}
                if (coordBegy >= y+(30*1) && coordBegy <= y+20+(30*1)) {labelEmpieza = 8}
                if (coordBegy >= y+(30*2) && coordBegy <= y+20+(30*2)) {labelEmpieza = 9}
                if (coordBegy >= y+(30*3) && coordBegy <= y+20+(30*3)) {labelEmpieza = 10}
                if (coordBegy >= y+(30*4) && coordBegy <= y+20+(30*4)) {labelEmpieza = 11}
                if (coordBegy >= y+(30*5) && coordBegy <= y+20+(30*5)) {labelEmpieza = 12}
                if (coordBegy >= y+(30*6) && coordBegy <= y+20+(30*6)) {labelEmpieza = 13}
                if (coordBegy >= y+(30*7) && coordBegy <= y+20+(30*7)) {labelEmpieza = 14}
                if (coordBegy >= y+(30*8) && coordBegy <= y+20+(30*8)) {labelEmpieza = 15}
                if (coordBegy >= y+(30*9) && coordBegy <= y+20+(30*9)) {labelEmpieza = 16}
                if (coordBegy >= y+(30*10) && coordBegy <= y+20+(30*10)) {labelEmpieza = 17}
                if (coordBegy >= y+(30*11) && coordBegy <= y+20+(30*11)) {labelEmpieza = 18}
                if (coordBegy >= y+(30*12) && coordBegy <= y+20+(30*12)) {labelEmpieza = 19}
                if (coordBegy >= y+(30*13) && coordBegy <= y+20+(30*13)) {labelEmpieza = 20}
                if (coordBegy >= y+(30*14) && coordBegy <= y+20+(30*14)) {labelEmpieza = 21}
                if (coordBegy >= y+(30*15) && coordBegy <= y+20+(30*15)) {labelEmpieza = 22}
            }
                // Miercoles
            else if (coordBegx >= 5+(screenWidth/7)*2 && coordBegx <= 5+(screenWidth/7)*3) {
                columnEmpieza = 3
                if (coordBegy >= y && coordBegy <= y+20) {labelEmpieza = 7}
                if (coordBegy >= y+(30*1) && coordBegy <= y+20+(30*1)) {labelEmpieza = 8}
                if (coordBegy >= y+(30*2) && coordBegy <= y+20+(30*2)) {labelEmpieza = 9}
                if (coordBegy >= y+(30*3) && coordBegy <= y+20+(30*3)) {labelEmpieza = 10}
                if (coordBegy >= y+(30*4) && coordBegy <= y+20+(30*4)) {labelEmpieza = 11}
                if (coordBegy >= y+(30*5) && coordBegy <= y+20+(30*5)) {labelEmpieza = 12}
                if (coordBegy >= y+(30*6) && coordBegy <= y+20+(30*6)) {labelEmpieza = 13}
                if (coordBegy >= y+(30*7) && coordBegy <= y+20+(30*7)) {labelEmpieza = 14}
                if (coordBegy >= y+(30*8) && coordBegy <= y+20+(30*8)) {labelEmpieza = 15}
                if (coordBegy >= y+(30*9) && coordBegy <= y+20+(30*9)) {labelEmpieza = 16}
                if (coordBegy >= y+(30*10) && coordBegy <= y+20+(30*10)) {labelEmpieza = 17}
                if (coordBegy >= y+(30*11) && coordBegy <= y+20+(30*11)) {labelEmpieza = 18}
                if (coordBegy >= y+(30*12) && coordBegy <= y+20+(30*12)) {labelEmpieza = 19}
                if (coordBegy >= y+(30*13) && coordBegy <= y+20+(30*13)) {labelEmpieza = 20}
                if (coordBegy >= y+(30*14) && coordBegy <= y+20+(30*14)) {labelEmpieza = 21}
                if (coordBegy >= y+(30*15) && coordBegy <= y+20+(30*15)) {labelEmpieza = 22}
            }
                // Jueves
            else if (coordBegx >= 5+(screenWidth/7)*3 && coordBegx <= 5+(screenWidth/7)*4) {
                columnEmpieza = 4
                if (coordBegy >= y && coordBegy <= y+20) {labelEmpieza = 7}
                if (coordBegy >= y+(30*1) && coordBegy <= y+20+(30*1)) {labelEmpieza = 8}
                if (coordBegy >= y+(30*2) && coordBegy <= y+20+(30*2)) {labelEmpieza = 9}
                if (coordBegy >= y+(30*3) && coordBegy <= y+20+(30*3)) {labelEmpieza = 10}
                if (coordBegy >= y+(30*4) && coordBegy <= y+20+(30*4)) {labelEmpieza = 11}
                if (coordBegy >= y+(30*5) && coordBegy <= y+20+(30*5)) {labelEmpieza = 12}
                if (coordBegy >= y+(30*6) && coordBegy <= y+20+(30*6)) {labelEmpieza = 13}
                if (coordBegy >= y+(30*7) && coordBegy <= y+20+(30*7)) {labelEmpieza = 14}
                if (coordBegy >= y+(30*8) && coordBegy <= y+20+(30*8)) {labelEmpieza = 15}
                if (coordBegy >= y+(30*9) && coordBegy <= y+20+(30*9)) {labelEmpieza = 16}
                if (coordBegy >= y+(30*10) && coordBegy <= y+20+(30*10)) {labelEmpieza = 17}
                if (coordBegy >= y+(30*11) && coordBegy <= y+20+(30*11)) {labelEmpieza = 18}
                if (coordBegy >= y+(30*12) && coordBegy <= y+20+(30*12)) {labelEmpieza = 19}
                if (coordBegy >= y+(30*13) && coordBegy <= y+20+(30*13)) {labelEmpieza = 20}
                if (coordBegy >= y+(30*14) && coordBegy <= y+20+(30*14)) {labelEmpieza = 21}
                if (coordBegy >= y+(30*15) && coordBegy <= y+20+(30*15)) {labelEmpieza = 22}
            }
                // Viernes
            else if (coordBegx >= 5+(screenWidth/7)*4 && coordBegx <= 5+(screenWidth/7)*5) {
                columnEmpieza = 5
                if (coordBegy >= y && coordBegy <= y+20) {labelEmpieza = 7}
                if (coordBegy >= y+(30*1) && coordBegy <= y+20+(30*1)) {labelEmpieza = 8}
                if (coordBegy >= y+(30*2) && coordBegy <= y+20+(30*2)) {labelEmpieza = 9}
                if (coordBegy >= y+(30*3) && coordBegy <= y+20+(30*3)) {labelEmpieza = 10}
                if (coordBegy >= y+(30*4) && coordBegy <= y+20+(30*4)) {labelEmpieza = 11}
                if (coordBegy >= y+(30*5) && coordBegy <= y+20+(30*5)) {labelEmpieza = 12}
                if (coordBegy >= y+(30*6) && coordBegy <= y+20+(30*6)) {labelEmpieza = 13}
                if (coordBegy >= y+(30*7) && coordBegy <= y+20+(30*7)) {labelEmpieza = 14}
                if (coordBegy >= y+(30*8) && coordBegy <= y+20+(30*8)) {labelEmpieza = 15}
                if (coordBegy >= y+(30*9) && coordBegy <= y+20+(30*9)) {labelEmpieza = 16}
                if (coordBegy >= y+(30*10) && coordBegy <= y+20+(30*10)) {labelEmpieza = 17}
                if (coordBegy >= y+(30*11) && coordBegy <= y+20+(30*11)) {labelEmpieza = 18}
                if (coordBegy >= y+(30*12) && coordBegy <= y+20+(30*12)) {labelEmpieza = 19}
                if (coordBegy >= y+(30*13) && coordBegy <= y+20+(30*13)) {labelEmpieza = 20}
                if (coordBegy >= y+(30*14) && coordBegy <= y+20+(30*14)) {labelEmpieza = 21}
                if (coordBegy >= y+(30*15) && coordBegy <= y+20+(30*15)) {labelEmpieza = 22}
            }
                // Sabado
            else if (coordBegx >= 5+(screenWidth/7)*5 && coordBegx <= 5+(screenWidth/7)*6) {
                columnEmpieza = 6
                if (coordBegy >= y && coordBegy <= y+20) {labelEmpieza = 7}
                if (coordBegy >= y+(30*1) && coordBegy <= y+20+(30*1)) {labelEmpieza = 8}
                if (coordBegy >= y+(30*2) && coordBegy <= y+20+(30*2)) {labelEmpieza = 9}
                if (coordBegy >= y+(30*3) && coordBegy <= y+20+(30*3)) {labelEmpieza = 10}
                if (coordBegy >= y+(30*4) && coordBegy <= y+20+(30*4)) {labelEmpieza = 11}
                if (coordBegy >= y+(30*5) && coordBegy <= y+20+(30*5)) {labelEmpieza = 12}
                if (coordBegy >= y+(30*6) && coordBegy <= y+20+(30*6)) {labelEmpieza = 13}
                if (coordBegy >= y+(30*7) && coordBegy <= y+20+(30*7)) {labelEmpieza = 14}
                if (coordBegy >= y+(30*8) && coordBegy <= y+20+(30*8)) {labelEmpieza = 15}
                if (coordBegy >= y+(30*9) && coordBegy <= y+20+(30*9)) {labelEmpieza = 16}
                if (coordBegy >= y+(30*10) && coordBegy <= y+20+(30*10)) {labelEmpieza = 17}
                if (coordBegy >= y+(30*11) && coordBegy <= y+20+(30*11)) {labelEmpieza = 18}
                if (coordBegy >= y+(30*12) && coordBegy <= y+20+(30*12)) {labelEmpieza = 19}
                if (coordBegy >= y+(30*13) && coordBegy <= y+20+(30*13)) {labelEmpieza = 20}
                if (coordBegy >= y+(30*14) && coordBegy <= y+20+(30*14)) {labelEmpieza = 21}
                if (coordBegy >= y+(30*15) && coordBegy <= y+20+(30*15)) {labelEmpieza = 22}
            }
                // Domingo
            else if (coordBegx >= 5+(screenWidth/7)*6 && coordBegx <= 5+(screenWidth/7)*7) {
                columnEmpieza = 7
                if (coordBegy >= y && coordBegy <= y+20) {labelEmpieza = 7}
                if (coordBegy >= y+(30*1) && coordBegy <= y+20+(30*1)) {labelEmpieza = 8}
                if (coordBegy >= y+(30*2) && coordBegy <= y+20+(30*2)) {labelEmpieza = 9}
                if (coordBegy >= y+(30*3) && coordBegy <= y+20+(30*3)) {labelEmpieza = 10}
                if (coordBegy >= y+(30*4) && coordBegy <= y+20+(30*4)) {labelEmpieza = 11}
                if (coordBegy >= y+(30*5) && coordBegy <= y+20+(30*5)) {labelEmpieza = 12}
                if (coordBegy >= y+(30*6) && coordBegy <= y+20+(30*6)) {labelEmpieza = 13}
                if (coordBegy >= y+(30*7) && coordBegy <= y+20+(30*7)) {labelEmpieza = 14}
                if (coordBegy >= y+(30*8) && coordBegy <= y+20+(30*8)) {labelEmpieza = 15}
                if (coordBegy >= y+(30*9) && coordBegy <= y+20+(30*9)) {labelEmpieza = 16}
                if (coordBegy >= y+(30*10) && coordBegy <= y+20+(30*10)) {labelEmpieza = 17}
                if (coordBegy >= y+(30*11) && coordBegy <= y+20+(30*11)) {labelEmpieza = 18}
                if (coordBegy >= y+(30*12) && coordBegy <= y+20+(30*12)) {labelEmpieza = 19}
                if (coordBegy >= y+(30*13) && coordBegy <= y+20+(30*13)) {labelEmpieza = 20}
                if (coordBegy >= y+(30*14) && coordBegy <= y+20+(30*14)) {labelEmpieza = 21}
                if (coordBegy >= y+(30*15) && coordBegy <= y+20+(30*15)) {labelEmpieza = 22}
            }
            
            
            if coordBegy >= y+(30*15)+20 {
                columnEmpieza = 0
                labelEmpieza = 0
            }
            
            //print("LABEL EMPIEZA: ", columnEmpieza, ", ", labelEmpieza)
        }
        
        func getLabelEnded(coordEndX: Int, coordEndY: Int) {
            let y = 150
                        
            // Lunes
            if (coordEndX >= 5 && coordEndX <= 5+(screenWidth/7)) {
                columnTermina = 1
                if (coordEndY >= y && coordEndY <= y+20) {labelTermina = 7}
                if (coordEndY >= y+(20 * 1) && coordEndY <= y+(30 * 1)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 1) && coordEndY <= y+20+(30 * 1)) {labelTermina = 8}
                if (coordEndY >= y+20+(30 * 1) && coordEndY <= y+(30 * 2)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 2) && coordEndY <= y+20+(30 * 2)) {labelTermina = 9}
                if (coordEndY >= y+20+(30 * 2) && coordEndY <= y+(30 * 3)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 3) && coordEndY <= y+20+(30 * 3)) {labelTermina = 10}
                if (coordEndY >= y+20+(30 * 3) && coordEndY <= y+(30 * 4)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 4) && coordEndY <= y+20+(30 * 4)) {labelTermina = 11}
                if (coordEndY >= y+20+(30 * 4) && coordEndY <= y+(30 * 5)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 5) && coordEndY <= y+20+(30 * 5)) {labelTermina = 12}
                if (coordEndY >= y+20+(30 * 5) && coordEndY <= y+(30 * 6)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 6) && coordEndY <= y+20+(30 * 6)) {labelTermina = 13}
                if (coordEndY >= y+20+(30 * 6) && coordEndY <= y+(30 * 7)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 7) && coordEndY <= y+20+(30 * 7)) {labelTermina = 14}
                if (coordEndY >= y+20+(30 * 7) && coordEndY <= y+(30 * 8)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 8) && coordEndY <= y+20+(30 * 8)) {labelTermina = 15}
                if (coordEndY >= y+20+(30 * 8) && coordEndY <= y+(30 * 9)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 9) && coordEndY <= y+20+(30 * 9)) {labelTermina = 16}
                if (coordEndY >= y+20+(30 * 9) && coordEndY <= y+(30 * 10)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 10) && coordEndY <= y+20+(30 * 10)) {labelTermina = 17}
                if (coordEndY >= y+20+(30 * 10) && coordEndY <= y+(30 * 11)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 11) && coordEndY <= y+20+(30 * 11)) {labelTermina = 18}
                if (coordEndY >= y+20+(30 * 11) && coordEndY <= y+(30 * 12)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 12) && coordEndY <= y+20+(30 * 12)) {labelTermina = 19}
                if (coordEndY >= y+20+(30 * 12) && coordEndY <= y+(30 * 13)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 13) && coordEndY <= y+20+(30 * 13)) {labelTermina = 20}
                if (coordEndY >= y+20+(30 * 13) && coordEndY <= y+(30 * 14)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 14) && coordEndY <= y+20+(30 * 14)) {labelTermina = 21}
                if (coordEndY >= y+20+(30 * 14) && coordEndY <= y+(30 * 15)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 15) && coordEndY <= y+20+(30 * 15)) {labelTermina = 22}
                if (coordEndY >= y+20+(30 * 15) && coordEndY <= y+(30 * 16)) {labelTermina = 0}
                
            }
                // Martes
            else if (coordEndX >= 5+(screenWidth/7) && coordEndX <= 5+(screenWidth/7)*2) {
                columnTermina = 2
                if (coordEndY >= y && coordEndY <= y+20) {labelTermina = 7}
                if (coordEndY >= y+(20 * 1) && coordEndY <= y+(30 * 1)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 1) && coordEndY <= y+20+(30 * 1)) {labelTermina = 8}
                if (coordEndY >= y+20+(30 * 1) && coordEndY <= y+(30 * 2)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 2) && coordEndY <= y+20+(30 * 2)) {labelTermina = 9}
                if (coordEndY >= y+20+(30 * 2) && coordEndY <= y+(30 * 3)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 3) && coordEndY <= y+20+(30 * 3)) {labelTermina = 10}
                if (coordEndY >= y+20+(30 * 3) && coordEndY <= y+(30 * 4)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 4) && coordEndY <= y+20+(30 * 4)) {labelTermina = 11}
                if (coordEndY >= y+20+(30 * 4) && coordEndY <= y+(30 * 5)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 5) && coordEndY <= y+20+(30 * 5)) {labelTermina = 12}
                if (coordEndY >= y+20+(30 * 5) && coordEndY <= y+(30 * 6)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 6) && coordEndY <= y+20+(30 * 6)) {labelTermina = 13}
                if (coordEndY >= y+20+(30 * 6) && coordEndY <= y+(30 * 7)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 7) && coordEndY <= y+20+(30 * 7)) {labelTermina = 14}
                if (coordEndY >= y+20+(30 * 7) && coordEndY <= y+(30 * 8)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 8) && coordEndY <= y+20+(30 * 8)) {labelTermina = 15}
                if (coordEndY >= y+20+(30 * 8) && coordEndY <= y+(30 * 9)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 9) && coordEndY <= y+20+(30 * 9)) {labelTermina = 16}
                if (coordEndY >= y+20+(30 * 9) && coordEndY <= y+(30 * 10)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 10) && coordEndY <= y+20+(30 * 10)) {labelTermina = 17}
                if (coordEndY >= y+20+(30 * 10) && coordEndY <= y+(30 * 11)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 11) && coordEndY <= y+20+(30 * 11)) {labelTermina = 18}
                if (coordEndY >= y+20+(30 * 11) && coordEndY <= y+(30 * 12)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 12) && coordEndY <= y+20+(30 * 12)) {labelTermina = 19}
                if (coordEndY >= y+20+(30 * 12) && coordEndY <= y+(30 * 13)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 13) && coordEndY <= y+20+(30 * 13)) {labelTermina = 20}
                if (coordEndY >= y+20+(30 * 13) && coordEndY <= y+(30 * 14)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 14) && coordEndY <= y+20+(30 * 14)) {labelTermina = 21}
                if (coordEndY >= y+20+(30 * 14) && coordEndY <= y+(30 * 15)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 15) && coordEndY <= y+20+(30 * 15)) {labelTermina = 22}
                if (coordEndY >= y+20+(30 * 15) && coordEndY <= y+(30 * 16)) {labelTermina = 0}
            }
                // Miercoles
            else if (coordEndX >= 5+(screenWidth/7)*2 && coordEndX <= 5+(screenWidth/7)*3) {
                columnTermina = 3
                if (coordEndY >= y && coordEndY <= y+20) {labelTermina = 7}
                if (coordEndY >= y+(20 * 1) && coordEndY <= y+(30 * 1)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 1) && coordEndY <= y+20+(30 * 1)) {labelTermina = 8}
                if (coordEndY >= y+20+(30 * 1) && coordEndY <= y+(30 * 2)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 2) && coordEndY <= y+20+(30 * 2)) {labelTermina = 9}
                if (coordEndY >= y+20+(30 * 2) && coordEndY <= y+(30 * 3)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 3) && coordEndY <= y+20+(30 * 3)) {labelTermina = 10}
                if (coordEndY >= y+20+(30 * 3) && coordEndY <= y+(30 * 4)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 4) && coordEndY <= y+20+(30 * 4)) {labelTermina = 11}
                if (coordEndY >= y+20+(30 * 4) && coordEndY <= y+(30 * 5)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 5) && coordEndY <= y+20+(30 * 5)) {labelTermina = 12}
                if (coordEndY >= y+20+(30 * 5) && coordEndY <= y+(30 * 6)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 6) && coordEndY <= y+20+(30 * 6)) {labelTermina = 13}
                if (coordEndY >= y+20+(30 * 6) && coordEndY <= y+(30 * 7)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 7) && coordEndY <= y+20+(30 * 7)) {labelTermina = 14}
                if (coordEndY >= y+20+(30 * 7) && coordEndY <= y+(30 * 8)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 8) && coordEndY <= y+20+(30 * 8)) {labelTermina = 15}
                if (coordEndY >= y+20+(30 * 8) && coordEndY <= y+(30 * 9)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 9) && coordEndY <= y+20+(30 * 9)) {labelTermina = 16}
                if (coordEndY >= y+20+(30 * 9) && coordEndY <= y+(30 * 10)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 10) && coordEndY <= y+20+(30 * 10)) {labelTermina = 17}
                if (coordEndY >= y+20+(30 * 10) && coordEndY <= y+(30 * 11)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 11) && coordEndY <= y+20+(30 * 11)) {labelTermina = 18}
                if (coordEndY >= y+20+(30 * 11) && coordEndY <= y+(30 * 12)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 12) && coordEndY <= y+20+(30 * 12)) {labelTermina = 19}
                if (coordEndY >= y+20+(30 * 12) && coordEndY <= y+(30 * 13)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 13) && coordEndY <= y+20+(30 * 13)) {labelTermina = 20}
                if (coordEndY >= y+20+(30 * 13) && coordEndY <= y+(30 * 14)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 14) && coordEndY <= y+20+(30 * 14)) {labelTermina = 21}
                if (coordEndY >= y+20+(30 * 14) && coordEndY <= y+(30 * 15)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 15) && coordEndY <= y+20+(30 * 15)) {labelTermina = 22}
                if (coordEndY >= y+20+(30 * 15) && coordEndY <= y+(30 * 16)) {labelTermina = 0}
            }
                // Jueves
            else if (coordEndX >= 5+(screenWidth/7)*3 && coordEndX <= 5+(screenWidth/7)*4) {
                columnTermina = 4
                if (coordEndY >= y && coordEndY <= y+20) {labelTermina = 7}
                if (coordEndY >= y+(20 * 1) && coordEndY <= y+(30 * 1)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 1) && coordEndY <= y+20+(30 * 1)) {labelTermina = 8}
                if (coordEndY >= y+20+(30 * 1) && coordEndY <= y+(30 * 2)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 2) && coordEndY <= y+20+(30 * 2)) {labelTermina = 9}
                if (coordEndY >= y+20+(30 * 2) && coordEndY <= y+(30 * 3)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 3) && coordEndY <= y+20+(30 * 3)) {labelTermina = 10}
                if (coordEndY >= y+20+(30 * 3) && coordEndY <= y+(30 * 4)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 4) && coordEndY <= y+20+(30 * 4)) {labelTermina = 11}
                if (coordEndY >= y+20+(30 * 4) && coordEndY <= y+(30 * 5)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 5) && coordEndY <= y+20+(30 * 5)) {labelTermina = 12}
                if (coordEndY >= y+20+(30 * 5) && coordEndY <= y+(30 * 6)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 6) && coordEndY <= y+20+(30 * 6)) {labelTermina = 13}
                if (coordEndY >= y+20+(30 * 6) && coordEndY <= y+(30 * 7)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 7) && coordEndY <= y+20+(30 * 7)) {labelTermina = 14}
                if (coordEndY >= y+20+(30 * 7) && coordEndY <= y+(30 * 8)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 8) && coordEndY <= y+20+(30 * 8)) {labelTermina = 15}
                if (coordEndY >= y+20+(30 * 8) && coordEndY <= y+(30 * 9)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 9) && coordEndY <= y+20+(30 * 9)) {labelTermina = 16}
                if (coordEndY >= y+20+(30 * 9) && coordEndY <= y+(30 * 10)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 10) && coordEndY <= y+20+(30 * 10)) {labelTermina = 17}
                if (coordEndY >= y+20+(30 * 10) && coordEndY <= y+(30 * 11)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 11) && coordEndY <= y+20+(30 * 11)) {labelTermina = 18}
                if (coordEndY >= y+20+(30 * 11) && coordEndY <= y+(30 * 12)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 12) && coordEndY <= y+20+(30 * 12)) {labelTermina = 19}
                if (coordEndY >= y+20+(30 * 12) && coordEndY <= y+(30 * 13)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 13) && coordEndY <= y+20+(30 * 13)) {labelTermina = 20}
                if (coordEndY >= y+20+(30 * 13) && coordEndY <= y+(30 * 14)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 14) && coordEndY <= y+20+(30 * 14)) {labelTermina = 21}
                if (coordEndY >= y+20+(30 * 14) && coordEndY <= y+(30 * 15)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 15) && coordEndY <= y+20+(30 * 15)) {labelTermina = 22}
                if (coordEndY >= y+20+(30 * 15) && coordEndY <= y+(30 * 16)) {labelTermina = 0}
            }
                // Viernes
            else if (coordEndX >= 5+(screenWidth/7)*4 && coordEndX <= 5+(screenWidth/7)*5) {
                columnTermina = 5
                if (coordEndY >= y && coordEndY <= y+20) {labelTermina = 7}
                if (coordEndY >= y+(20 * 1) && coordEndY <= y+(30 * 1)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 1) && coordEndY <= y+20+(30 * 1)) {labelTermina = 8}
                if (coordEndY >= y+20+(30 * 1) && coordEndY <= y+(30 * 2)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 2) && coordEndY <= y+20+(30 * 2)) {labelTermina = 9}
                if (coordEndY >= y+20+(30 * 2) && coordEndY <= y+(30 * 3)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 3) && coordEndY <= y+20+(30 * 3)) {labelTermina = 10}
                if (coordEndY >= y+20+(30 * 3) && coordEndY <= y+(30 * 4)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 4) && coordEndY <= y+20+(30 * 4)) {labelTermina = 11}
                if (coordEndY >= y+20+(30 * 4) && coordEndY <= y+(30 * 5)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 5) && coordEndY <= y+20+(30 * 5)) {labelTermina = 12}
                if (coordEndY >= y+20+(30 * 5) && coordEndY <= y+(30 * 6)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 6) && coordEndY <= y+20+(30 * 6)) {labelTermina = 13}
                if (coordEndY >= y+20+(30 * 6) && coordEndY <= y+(30 * 7)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 7) && coordEndY <= y+20+(30 * 7)) {labelTermina = 14}
                if (coordEndY >= y+20+(30 * 7) && coordEndY <= y+(30 * 8)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 8) && coordEndY <= y+20+(30 * 8)) {labelTermina = 15}
                if (coordEndY >= y+20+(30 * 8) && coordEndY <= y+(30 * 9)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 9) && coordEndY <= y+20+(30 * 9)) {labelTermina = 16}
                if (coordEndY >= y+20+(30 * 9) && coordEndY <= y+(30 * 10)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 10) && coordEndY <= y+20+(30 * 10)) {labelTermina = 17}
                if (coordEndY >= y+20+(30 * 10) && coordEndY <= y+(30 * 11)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 11) && coordEndY <= y+20+(30 * 11)) {labelTermina = 18}
                if (coordEndY >= y+20+(30 * 11) && coordEndY <= y+(30 * 12)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 12) && coordEndY <= y+20+(30 * 12)) {labelTermina = 19}
                if (coordEndY >= y+20+(30 * 12) && coordEndY <= y+(30 * 13)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 13) && coordEndY <= y+20+(30 * 13)) {labelTermina = 20}
                if (coordEndY >= y+20+(30 * 13) && coordEndY <= y+(30 * 14)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 14) && coordEndY <= y+20+(30 * 14)) {labelTermina = 21}
                if (coordEndY >= y+20+(30 * 14) && coordEndY <= y+(30 * 15)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 15) && coordEndY <= y+20+(30 * 15)) {labelTermina = 22}
                if (coordEndY >= y+20+(30 * 15) && coordEndY <= y+(30 * 16)) {labelTermina = 0}
            }
                // Sabado
            else if (coordEndX >= 5+(screenWidth/7)*5 && coordEndX <= 5+(screenWidth/7)*6) {
                columnTermina = 6
                if (coordEndY >= y && coordEndY <= y+20) {labelTermina = 7}
                if (coordEndY >= y+(20 * 1) && coordEndY <= y+(30 * 1)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 1) && coordEndY <= y+20+(30 * 1)) {labelTermina = 8}
                if (coordEndY >= y+20+(30 * 1) && coordEndY <= y+(30 * 2)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 2) && coordEndY <= y+20+(30 * 2)) {labelTermina = 9}
                if (coordEndY >= y+20+(30 * 2) && coordEndY <= y+(30 * 3)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 3) && coordEndY <= y+20+(30 * 3)) {labelTermina = 10}
                if (coordEndY >= y+20+(30 * 3) && coordEndY <= y+(30 * 4)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 4) && coordEndY <= y+20+(30 * 4)) {labelTermina = 11}
                if (coordEndY >= y+20+(30 * 4) && coordEndY <= y+(30 * 5)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 5) && coordEndY <= y+20+(30 * 5)) {labelTermina = 12}
                if (coordEndY >= y+20+(30 * 5) && coordEndY <= y+(30 * 6)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 6) && coordEndY <= y+20+(30 * 6)) {labelTermina = 13}
                if (coordEndY >= y+20+(30 * 6) && coordEndY <= y+(30 * 7)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 7) && coordEndY <= y+20+(30 * 7)) {labelTermina = 14}
                if (coordEndY >= y+20+(30 * 7) && coordEndY <= y+(30 * 8)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 8) && coordEndY <= y+20+(30 * 8)) {labelTermina = 15}
                if (coordEndY >= y+20+(30 * 8) && coordEndY <= y+(30 * 9)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 9) && coordEndY <= y+20+(30 * 9)) {labelTermina = 16}
                if (coordEndY >= y+20+(30 * 9) && coordEndY <= y+(30 * 10)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 10) && coordEndY <= y+20+(30 * 10)) {labelTermina = 17}
                if (coordEndY >= y+20+(30 * 10) && coordEndY <= y+(30 * 11)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 11) && coordEndY <= y+20+(30 * 11)) {labelTermina = 18}
                if (coordEndY >= y+20+(30 * 11) && coordEndY <= y+(30 * 12)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 12) && coordEndY <= y+20+(30 * 12)) {labelTermina = 19}
                if (coordEndY >= y+20+(30 * 12) && coordEndY <= y+(30 * 13)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 13) && coordEndY <= y+20+(30 * 13)) {labelTermina = 20}
                if (coordEndY >= y+20+(30 * 13) && coordEndY <= y+(30 * 14)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 14) && coordEndY <= y+20+(30 * 14)) {labelTermina = 21}
                if (coordEndY >= y+20+(30 * 14) && coordEndY <= y+(30 * 15)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 15) && coordEndY <= y+20+(30 * 15)) {labelTermina = 22}
                if (coordEndY >= y+20+(30 * 15) && coordEndY <= y+(30 * 16)) {labelTermina = 0}
            }
                // Domingo
            else if (coordEndX >= 5+(screenWidth/7)*6 && coordEndX <= 5+(screenWidth/7)*7) {
                columnTermina = 7
                if (coordEndY >= y && coordEndY <= y+20) {labelTermina = 7}
                if (coordEndY >= y+(20 * 1) && coordEndY <= y+(30 * 1)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 1) && coordEndY <= y+20+(30 * 1)) {labelTermina = 8}
                if (coordEndY >= y+20+(30 * 1) && coordEndY <= y+(30 * 2)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 2) && coordEndY <= y+20+(30 * 2)) {labelTermina = 9}
                if (coordEndY >= y+20+(30 * 2) && coordEndY <= y+(30 * 3)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 3) && coordEndY <= y+20+(30 * 3)) {labelTermina = 10}
                if (coordEndY >= y+20+(30 * 3) && coordEndY <= y+(30 * 4)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 4) && coordEndY <= y+20+(30 * 4)) {labelTermina = 11}
                if (coordEndY >= y+20+(30 * 4) && coordEndY <= y+(30 * 5)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 5) && coordEndY <= y+20+(30 * 5)) {labelTermina = 12}
                if (coordEndY >= y+20+(30 * 5) && coordEndY <= y+(30 * 6)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 6) && coordEndY <= y+20+(30 * 6)) {labelTermina = 13}
                if (coordEndY >= y+20+(30 * 6) && coordEndY <= y+(30 * 7)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 7) && coordEndY <= y+20+(30 * 7)) {labelTermina = 14}
                if (coordEndY >= y+20+(30 * 7) && coordEndY <= y+(30 * 8)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 8) && coordEndY <= y+20+(30 * 8)) {labelTermina = 15}
                if (coordEndY >= y+20+(30 * 8) && coordEndY <= y+(30 * 9)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 9) && coordEndY <= y+20+(30 * 9)) {labelTermina = 16}
                if (coordEndY >= y+20+(30 * 9) && coordEndY <= y+(30 * 10)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 10) && coordEndY <= y+20+(30 * 10)) {labelTermina = 17}
                if (coordEndY >= y+20+(30 * 10) && coordEndY <= y+(30 * 11)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 11) && coordEndY <= y+20+(30 * 11)) {labelTermina = 18}
                if (coordEndY >= y+20+(30 * 11) && coordEndY <= y+(30 * 12)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 12) && coordEndY <= y+20+(30 * 12)) {labelTermina = 19}
                if (coordEndY >= y+20+(30 * 12) && coordEndY <= y+(30 * 13)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 13) && coordEndY <= y+20+(30 * 13)) {labelTermina = 20}
                if (coordEndY >= y+20+(30 * 13) && coordEndY <= y+(30 * 14)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 14) && coordEndY <= y+20+(30 * 14)) {labelTermina = 21}
                if (coordEndY >= y+20+(30 * 14) && coordEndY <= y+(30 * 15)) {labelTermina = 0}
                
                if (coordEndY >= y+(30 * 15) && coordEndY <= y+20+(30 * 15)) {labelTermina = 22}
                if (coordEndY >= y+20+(30 * 15) && coordEndY <= y+(30 * 16)) {labelTermina = 0}
                
                
            }
            
            if coordEndY >= y+(30*15)+20{
                columnTermina = 0
                labelTermina = 0
            }
            
            
            //print("LABEL TERMINA: ", columnTermina, ", ", labelTermina)
        }
    
        func fillLabels (){
            
            if (columnEmpieza == nil || columnTermina == nil || labelEmpieza == nil || labelTermina == nil || columnEmpieza == 0 || columnTermina == 0 || labelEmpieza == 0 || labelTermina == 0) {
                return
            }
            
            if (columnEmpieza >= columnTermina) {
                let temp = columnEmpieza
                columnEmpieza = columnTermina
                columnTermina = temp
            }
            
            if (labelEmpieza >= labelTermina) {
                let temp = labelEmpieza
                labelEmpieza = labelTermina
                labelTermina = temp
            }
            
            for i in columnEmpieza..<columnTermina+1 {
                switch i {
                case 1:
                    for j in labelEmpieza..<labelTermina+1 {
                        switch j {
                        case 7:
                            if (listaLabel[7].backgroundColor == UIColor.green) {
                                listaLabel[7].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[7].backgroundColor = UIColor.green
                            }
                        case 8:
                            if (listaLabel[14].backgroundColor == UIColor.green) {
                                listaLabel[14].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[14].backgroundColor = UIColor.green
                            }
                        case 9:
                            if (listaLabel[21].backgroundColor == UIColor.green) {
                                listaLabel[21].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[21].backgroundColor = UIColor.green
                            }
                        case 10:
                            if (listaLabel[28].backgroundColor == UIColor.green) {
                                listaLabel[28].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[28].backgroundColor = UIColor.green
                            }
                        case 11:
                            if (listaLabel[35].backgroundColor == UIColor.green) {
                                listaLabel[35].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[35].backgroundColor = UIColor.green
                            }
                        case 12:
                            if (listaLabel[42].backgroundColor == UIColor.green) {
                                listaLabel[42].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[42].backgroundColor = UIColor.green
                            }
                        case 13:
                            if (listaLabel[49].backgroundColor == UIColor.green) {
                                listaLabel[49].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[49].backgroundColor = UIColor.green
                            }
                        case 14:
                            if (listaLabel[56].backgroundColor == UIColor.green) {
                                listaLabel[56].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[56].backgroundColor = UIColor.green
                            }
                        case 15:
                            if (listaLabel[63].backgroundColor == UIColor.green) {
                                listaLabel[63].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[63].backgroundColor = UIColor.green
                            }
                        case 16:
                            if (listaLabel[70].backgroundColor == UIColor.green) {
                                listaLabel[70].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[70].backgroundColor = UIColor.green
                            }
                        case 17:
                            if (listaLabel[77].backgroundColor == UIColor.green) {
                                listaLabel[77].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[77].backgroundColor = UIColor.green
                            }
                        case 18:
                            if (listaLabel[84].backgroundColor == UIColor.green) {
                                listaLabel[84].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[84].backgroundColor = UIColor.green
                            }
                        case 19:
                            if (listaLabel[91].backgroundColor == UIColor.green) {
                                listaLabel[91].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[91].backgroundColor = UIColor.green
                            }
                        case 20:
                            if (listaLabel[98].backgroundColor == UIColor.green) {
                                listaLabel[98].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[98].backgroundColor = UIColor.green
                            }
                        case 21:
                            if (listaLabel[105].backgroundColor == UIColor.green) {
                                listaLabel[105].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[105].backgroundColor = UIColor.green
                            }
                        case 22:
                            if (listaLabel[112].backgroundColor == UIColor.green) {
                                listaLabel[112].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[112].backgroundColor = UIColor.green
                            }
                        default:
                            print("nada")
                        }
                    }
                case 2:
                    for j in labelEmpieza..<labelTermina+1 {
                        switch j {
                        case 7:
                            if (listaLabel[8].backgroundColor == UIColor.green) {
                                listaLabel[8].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[8].backgroundColor = UIColor.green
                            }
                        case 8:
                            if (listaLabel[15].backgroundColor == UIColor.green) {
                                listaLabel[15].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[15].backgroundColor = UIColor.green
                            }
                        case 9:
                            if (listaLabel[22].backgroundColor == UIColor.green) {
                                listaLabel[22].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[22].backgroundColor = UIColor.green
                            }
                        case 10:
                            if (listaLabel[29].backgroundColor == UIColor.green) {
                                listaLabel[29].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[29].backgroundColor = UIColor.green
                            }
                        case 11:
                            if (listaLabel[36].backgroundColor == UIColor.green) {
                                listaLabel[36].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[36].backgroundColor = UIColor.green
                            }
                        case 12:
                            if (listaLabel[43].backgroundColor == UIColor.green) {
                                listaLabel[43].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[43].backgroundColor = UIColor.green
                            }
                        case 13:
                            if (listaLabel[50].backgroundColor == UIColor.green) {
                                listaLabel[50].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[50].backgroundColor = UIColor.green
                            }
                        case 14:
                            if (listaLabel[57].backgroundColor == UIColor.green) {
                                listaLabel[57].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[57].backgroundColor = UIColor.green
                            }
                        case 15:
                            if (listaLabel[64].backgroundColor == UIColor.green) {
                                listaLabel[64].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[64].backgroundColor = UIColor.green
                            }
                        case 16:
                            if (listaLabel[71].backgroundColor == UIColor.green) {
                                listaLabel[71].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[71].backgroundColor = UIColor.green
                            }
                        case 17:
                            if (listaLabel[78].backgroundColor == UIColor.green) {
                                listaLabel[78].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[78].backgroundColor = UIColor.green
                            }
                        case 18:
                            if (listaLabel[85].backgroundColor == UIColor.green) {
                                listaLabel[85].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[85].backgroundColor = UIColor.green
                            }
                        case 19:
                            if (listaLabel[92].backgroundColor == UIColor.green) {
                                listaLabel[92].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[92].backgroundColor = UIColor.green
                            }
                        case 20:
                            if (listaLabel[99].backgroundColor == UIColor.green) {
                                listaLabel[99].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[99].backgroundColor = UIColor.green
                            }
                        case 21:
                            if (listaLabel[106].backgroundColor == UIColor.green) {
                                listaLabel[106].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[106].backgroundColor = UIColor.green
                            }
                        case 22:
                            if (listaLabel[113].backgroundColor == UIColor.green) {
                                listaLabel[113].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[113].backgroundColor = UIColor.green
                            }
                        default:
                            print("nada")
                        }
                    }
                case 3:
                    for j in labelEmpieza..<labelTermina+1 {
                        switch j {
                        case 7:
                            if (listaLabel[9].backgroundColor == UIColor.green) {
                                listaLabel[9].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[9].backgroundColor = UIColor.green
                            }
                        case 8:
                            if (listaLabel[16].backgroundColor == UIColor.green) {
                                listaLabel[16].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[16].backgroundColor = UIColor.green
                            }
                        case 9:
                            if (listaLabel[23].backgroundColor == UIColor.green) {
                                listaLabel[23].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[23].backgroundColor = UIColor.green
                            }
                        case 10:
                            if (listaLabel[30].backgroundColor == UIColor.green) {
                                listaLabel[30].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[30].backgroundColor = UIColor.green
                            }
                        case 11:
                            if (listaLabel[37].backgroundColor == UIColor.green) {
                                listaLabel[37].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[37].backgroundColor = UIColor.green
                            }
                        case 12:
                            if (listaLabel[44].backgroundColor == UIColor.green) {
                                listaLabel[44].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[44].backgroundColor = UIColor.green
                            }
                        case 13:
                            if (listaLabel[51].backgroundColor == UIColor.green) {
                                listaLabel[51].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[51].backgroundColor = UIColor.green
                            }
                        case 14:
                            if (listaLabel[58].backgroundColor == UIColor.green) {
                                listaLabel[58].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[58].backgroundColor = UIColor.green
                            }
                        case 15:
                            if (listaLabel[65].backgroundColor == UIColor.green) {
                                listaLabel[65].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[65].backgroundColor = UIColor.green
                            }
                        case 16:
                            if (listaLabel[72].backgroundColor == UIColor.green) {
                                listaLabel[72].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[72].backgroundColor = UIColor.green
                            }
                        case 17:
                            if (listaLabel[79].backgroundColor == UIColor.green) {
                                listaLabel[79].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[79].backgroundColor = UIColor.green
                            }
                        case 18:
                            if (listaLabel[86].backgroundColor == UIColor.green) {
                                listaLabel[86].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[86].backgroundColor = UIColor.green
                            }
                        case 19:
                            if (listaLabel[93].backgroundColor == UIColor.green) {
                                listaLabel[93].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[93].backgroundColor = UIColor.green
                            }
                        case 20:
                            if (listaLabel[100].backgroundColor == UIColor.green) {
                                listaLabel[100].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[100].backgroundColor = UIColor.green
                            }
                        case 21:
                            if (listaLabel[107].backgroundColor == UIColor.green) {
                                listaLabel[107].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[107].backgroundColor = UIColor.green
                            }
                        case 22:
                            if (listaLabel[114].backgroundColor == UIColor.green) {
                                listaLabel[114].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[114].backgroundColor = UIColor.green
                            }
                        default:
                            print("nada")
                        }
                    }
                case 4:
                    for j in labelEmpieza..<labelTermina+1 {
                        switch j {
                        case 7:
                            if (listaLabel[10].backgroundColor == UIColor.green) {
                                listaLabel[10].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[10].backgroundColor = UIColor.green
                            }
                        case 8:
                            if (listaLabel[17].backgroundColor == UIColor.green) {
                                listaLabel[17].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[17].backgroundColor = UIColor.green
                            }
                        case 9:
                            if (listaLabel[24].backgroundColor == UIColor.green) {
                                listaLabel[24].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[24].backgroundColor = UIColor.green
                            }
                        case 10:
                            if (listaLabel[31].backgroundColor == UIColor.green) {
                                listaLabel[31].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[31].backgroundColor = UIColor.green
                            }
                        case 11:
                            if (listaLabel[38].backgroundColor == UIColor.green) {
                                listaLabel[38].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[38].backgroundColor = UIColor.green
                            }
                        case 12:
                            if (listaLabel[45].backgroundColor == UIColor.green) {
                                listaLabel[45].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[45].backgroundColor = UIColor.green
                            }
                        case 13:
                            if (listaLabel[52].backgroundColor == UIColor.green) {
                                listaLabel[52].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[52].backgroundColor = UIColor.green
                            }
                        case 14:
                            if (listaLabel[59].backgroundColor == UIColor.green) {
                                listaLabel[59].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[59].backgroundColor = UIColor.green
                            }
                        case 15:
                            if (listaLabel[66].backgroundColor == UIColor.green) {
                                listaLabel[66].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[66].backgroundColor = UIColor.green
                            }
                        case 16:
                            if (listaLabel[73].backgroundColor == UIColor.green) {
                                listaLabel[73].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[73].backgroundColor = UIColor.green
                            }
                        case 17:
                            if (listaLabel[80].backgroundColor == UIColor.green) {
                                listaLabel[80].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[80].backgroundColor = UIColor.green
                            }
                        case 18:
                            if (listaLabel[87].backgroundColor == UIColor.green) {
                                listaLabel[87].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[87].backgroundColor = UIColor.green
                            }
                        case 19:
                            if (listaLabel[94].backgroundColor == UIColor.green) {
                                listaLabel[94].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[94].backgroundColor = UIColor.green
                            }
                        case 20:
                            if (listaLabel[101].backgroundColor == UIColor.green) {
                                listaLabel[101].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[101].backgroundColor = UIColor.green
                            }
                        case 21:
                            if (listaLabel[108].backgroundColor == UIColor.green) {
                                listaLabel[108].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[108].backgroundColor = UIColor.green
                            }
                        case 22:
                            if (listaLabel[115].backgroundColor == UIColor.green) {
                                listaLabel[115].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[115].backgroundColor = UIColor.green
                            }
                        default:
                            print("nada")
                        }
                    }
                case 5:
                    for j in labelEmpieza..<labelTermina+1 {
                        switch j {
                        case 7:
                            if (listaLabel[11].backgroundColor == UIColor.green) {
                                listaLabel[11].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[11].backgroundColor = UIColor.green
                            }
                        case 8:
                            if (listaLabel[18].backgroundColor == UIColor.green) {
                                listaLabel[18].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[18].backgroundColor = UIColor.green
                            }
                        case 9:
                            if (listaLabel[25].backgroundColor == UIColor.green) {
                                listaLabel[25].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[25].backgroundColor = UIColor.green
                            }
                        case 10:
                            if (listaLabel[32].backgroundColor == UIColor.green) {
                                listaLabel[32].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[32].backgroundColor = UIColor.green
                            }
                        case 11:
                            if (listaLabel[39].backgroundColor == UIColor.green) {
                                listaLabel[39].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[39].backgroundColor = UIColor.green
                            }
                        case 12:
                            if (listaLabel[46].backgroundColor == UIColor.green) {
                                listaLabel[46].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[46].backgroundColor = UIColor.green
                            }
                        case 13:
                            if (listaLabel[53].backgroundColor == UIColor.green) {
                                listaLabel[53].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[53].backgroundColor = UIColor.green
                            }
                        case 14:
                            if (listaLabel[60].backgroundColor == UIColor.green) {
                                listaLabel[60].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[60].backgroundColor = UIColor.green
                            }
                        case 15:
                            if (listaLabel[67].backgroundColor == UIColor.green) {
                                listaLabel[67].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[67].backgroundColor = UIColor.green
                            }
                        case 16:
                            if (listaLabel[74].backgroundColor == UIColor.green) {
                                listaLabel[74].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[74].backgroundColor = UIColor.green
                            }
                        case 17:
                            if (listaLabel[81].backgroundColor == UIColor.green) {
                                listaLabel[81].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[81].backgroundColor = UIColor.green
                            }
                        case 18:
                            if (listaLabel[88].backgroundColor == UIColor.green) {
                                listaLabel[88].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[88].backgroundColor = UIColor.green
                            }
                        case 19:
                            if (listaLabel[95].backgroundColor == UIColor.green) {
                                listaLabel[95].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[95].backgroundColor = UIColor.green
                            }
                        case 20:
                            if (listaLabel[102].backgroundColor == UIColor.green) {
                                listaLabel[102].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[102].backgroundColor = UIColor.green
                            }
                        case 21:
                            if (listaLabel[109].backgroundColor == UIColor.green) {
                                listaLabel[109].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[109].backgroundColor = UIColor.green
                            }
                        case 22:
                            if (listaLabel[116].backgroundColor == UIColor.green) {
                                listaLabel[116].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[116].backgroundColor = UIColor.green
                            }
                        default:
                            print("nada")
                        }
                    }
                case 6:
                    for j in labelEmpieza..<labelTermina+1 {
                        switch j {
                        case 7:
                            if (listaLabel[12].backgroundColor == UIColor.green) {
                                listaLabel[12].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[12].backgroundColor = UIColor.green
                            }
                        case 8:
                            if (listaLabel[19].backgroundColor == UIColor.green) {
                                listaLabel[19].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[19].backgroundColor = UIColor.green
                            }
                        case 9:
                            if (listaLabel[26].backgroundColor == UIColor.green) {
                                listaLabel[26].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[26].backgroundColor = UIColor.green
                            }
                        case 10:
                            if (listaLabel[33].backgroundColor == UIColor.green) {
                                listaLabel[33].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[33].backgroundColor = UIColor.green
                            }
                        case 11:
                            if (listaLabel[40].backgroundColor == UIColor.green) {
                                listaLabel[40].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[40].backgroundColor = UIColor.green
                            }
                        case 12:
                            if (listaLabel[47].backgroundColor == UIColor.green) {
                                listaLabel[47].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[47].backgroundColor = UIColor.green
                            }
                        case 13:
                            if (listaLabel[54].backgroundColor == UIColor.green) {
                                listaLabel[54].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[54].backgroundColor = UIColor.green
                            }
                        case 14:
                            if (listaLabel[61].backgroundColor == UIColor.green) {
                                listaLabel[61].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[61].backgroundColor = UIColor.green
                            }
                        case 15:
                            if (listaLabel[68].backgroundColor == UIColor.green) {
                                listaLabel[68].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[68].backgroundColor = UIColor.green
                            }
                        case 16:
                            if (listaLabel[75].backgroundColor == UIColor.green) {
                                listaLabel[75].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[75].backgroundColor = UIColor.green
                            }
                        case 17:
                            if (listaLabel[82].backgroundColor == UIColor.green) {
                                listaLabel[82].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[82].backgroundColor = UIColor.green
                            }
                        case 18:
                            if (listaLabel[89].backgroundColor == UIColor.green) {
                                listaLabel[89].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[89].backgroundColor = UIColor.green
                            }
                        case 19:
                            if (listaLabel[96].backgroundColor == UIColor.green) {
                                listaLabel[96].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[96].backgroundColor = UIColor.green
                            }
                        case 20:
                            if (listaLabel[103].backgroundColor == UIColor.green) {
                                listaLabel[103].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[103].backgroundColor = UIColor.green
                            }
                        case 21:
                            if (listaLabel[110].backgroundColor == UIColor.green) {
                                listaLabel[110].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[110].backgroundColor = UIColor.green
                            }
                        case 22:
                            if (listaLabel[117].backgroundColor == UIColor.green) {
                                listaLabel[117].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[117].backgroundColor = UIColor.green
                            }
                        default:
                            print("nada")
                        }
                    }
                case 7:
                    for j in labelEmpieza..<labelTermina+1 {
                        switch j {
                        case 7:
                            if (listaLabel[13].backgroundColor == UIColor.green) {
                                listaLabel[13].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[13].backgroundColor = UIColor.green
                            }
                        case 8:
                            if (listaLabel[20].backgroundColor == UIColor.green) {
                                listaLabel[20].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[20].backgroundColor = UIColor.green
                            }
                        case 9:
                            if (listaLabel[27].backgroundColor == UIColor.green) {
                                listaLabel[27].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[27].backgroundColor = UIColor.green
                            }
                        case 10:
                            if (listaLabel[34].backgroundColor == UIColor.green) {
                                listaLabel[34].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[34].backgroundColor = UIColor.green
                            }
                        case 11:
                            if (listaLabel[41].backgroundColor == UIColor.green) {
                                listaLabel[41].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[41].backgroundColor = UIColor.green
                            }
                        case 12:
                            if (listaLabel[48].backgroundColor == UIColor.green) {
                                listaLabel[48].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[48].backgroundColor = UIColor.green
                            }
                        case 13:
                            if (listaLabel[55].backgroundColor == UIColor.green) {
                                listaLabel[55].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[55].backgroundColor = UIColor.green
                            }
                        case 14:
                            if (listaLabel[62].backgroundColor == UIColor.green) {
                                listaLabel[62].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[62].backgroundColor = UIColor.green
                            }
                        case 15:
                            if (listaLabel[69].backgroundColor == UIColor.green) {
                                listaLabel[69].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[69].backgroundColor = UIColor.green
                            }
                        case 16:
                            if (listaLabel[76].backgroundColor == UIColor.green) {
                                listaLabel[76].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[76].backgroundColor = UIColor.green
                            }
                        case 17:
                            if (listaLabel[83].backgroundColor == UIColor.green) {
                                listaLabel[83].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[83].backgroundColor = UIColor.green
                            }
                        case 18:
                            if (listaLabel[90].backgroundColor == UIColor.green) {
                                listaLabel[90].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[90].backgroundColor = UIColor.green
                            }
                        case 19:
                            if (listaLabel[97].backgroundColor == UIColor.green) {
                                listaLabel[97].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[97].backgroundColor = UIColor.green
                            }
                        case 20:
                            if (listaLabel[104].backgroundColor == UIColor.green) {
                                listaLabel[104].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[104].backgroundColor = UIColor.green
                            }
                        case 21:
                            if (listaLabel[111].backgroundColor == UIColor.green) {
                                listaLabel[111].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[111].backgroundColor = UIColor.green
                            }
                        case 22:
                            if (listaLabel[118].backgroundColor == UIColor.green) {
                                listaLabel[118].backgroundColor = UIColor.clear
                            } else {
                                listaLabel[118].backgroundColor = UIColor.green
                            }
                        default:
                            print("nada")
                        }
                    }
                default:
                    print("nada")
                }
            }
        }
     func p(){
            let rootRef = Database.database().reference().child(name!)
            let post = ["eventSchedules": arrTot ]
                    let index = String(indexRow!)
            rootRef.child("events").child(index).updateChildValues(post)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if (segue.identifier == "set") {
            let info = segue.destination as! SetEventViewController
            info.unEvento =  unEvento
            info.indexRow = indexRow

        }
    }
    
}

