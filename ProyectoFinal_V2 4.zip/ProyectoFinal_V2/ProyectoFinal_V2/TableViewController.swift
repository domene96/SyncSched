import UIKit
import Firebase
import FirebaseDatabase


class TableViewController: UITableViewController {
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        return UIInterfaceOrientationMask.portrait
    }
    override var shouldAutorotate: Bool {
        return false
    }
    let delegate = UIApplication.shared.delegate as! AppDelegate
    
    var ArrayEventos: [Event] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let name = delegate.name
        print(name)
        let rootRef = Database.database().reference().child(name!)
        
        rootRef.observe(.value, with: { snapshot in
            
            var newItems: [Event] = []
            
            let value = snapshot.value as? NSDictionary
            
            let todosEventos = value?["events"] as? NSArray
            let length = todosEventos?.count as? Int
            var i = 0
            while i != length {
                let temp = todosEventos?[i] as? NSDictionary
                let eventName = temp?["eventName"] as? String ?? ""
                let eventFinalDate = temp?["eventFinalDate"] as? String ?? ""
                let eventFinalLocation = temp?["eventFinalLocation"] as? String ?? ""
                let eventOrganizer = temp?["eventOrganizer"] as? String ?? ""
                let eventState = temp?["eventState"] as? String ?? ""
                let eventLocations = temp?["eventLocations"] as? String ?? ""
                let eventSchedules = temp?["eventSchedules"] as? NSArray ?? []
                let eventMembers = temp?["eventMembers"] as? NSArray ?? []
                let initialDate = temp?["initialDate"] as? Int ?? 0
                let initialYear = temp?["initialYear"] as? Int ?? 0
                let initialMonth = temp?["initialMonth"] as? Int ?? 0
                
                
                let event = Event(eventFinalDate: eventFinalDate, eventFinalLocation: eventFinalLocation ,eventLocations: eventLocations,eventMembers: eventMembers,eventName: eventName,eventOrganizer: eventOrganizer,eventSchedules: eventSchedules,eventState: eventState, initialDate : initialDate , initialYear : initialYear, initialMonth : initialMonth)
                
                newItems.append(event)
                i = i+1
            }
            
            self.ArrayEventos = newItems
            self.tableView.reloadData()
            //print(self.ArrayEventos)
        })
    }
    
    
    // MARK: - Table view data source
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return ArrayEventos.count
    }
    
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        let event = ArrayEventos[indexPath.row]
        cell.textLabel?.text = String( event.eventName)
        cell.detailTextLabel?.text = String( event.eventFinalDate)
        if(event.eventState == "rojo"){
            cell.imageView?.image = #imageLiteral(resourceName: "red")
        }
        else if(event.eventState == "verde"){
            cell.imageView?.image = #imageLiteral(resourceName: "green")
        }
        else if(event.eventState == "amarillo"){
            cell.imageView?.image = #imageLiteral(resourceName: "yellow")
        }
        
        
        return cell
    }
    
    //    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
    //        let indice = tableView.indexPathForSelectedRow
    //        let row = ArrayEventos[(indice?.row)!]
    //        print(row)
    //        if row.eventState == "verde"{
    //            self.performSegue(withIdentifier: "info", sender: indexPath);
    //
    //
    //        }else{
    //            self.performSegue(withIdentifier: "tabla", sender: indexPath);
    //
    //        }
    //
    //    }
    //
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if (segue.identifier == "info") {
            let indexPath = tableView.indexPathForSelectedRow
            let selectedRow = indexPath!.row
            let info = segue.destination as! ViewControllerInfo
            info.unEvento = self.ArrayEventos[selectedRow]
            
        }else if (segue.identifier == "tabla"){
            let indexPath = tableView.indexPathForSelectedRow
            let selectedRow = indexPath!.row
            let info = segue.destination as! ViewControllerTabla
             info.unEvento = self.ArrayEventos[selectedRow]
             info.indexRow = selectedRow
            
        }
    }
    
    
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let indice = tableView.indexPathForSelectedRow
        let row = ArrayEventos[(indice?.row)!]
        //print(row)
        if row.eventState == "verde"{
            performSegue(withIdentifier: "info", sender: self)
            
        }else{
            performSegue(withIdentifier: "tabla", sender: self)
            
        }
    }
    
    
    
}


